energy = [Total Renewable,Solar photovoltaic,Solar thermal energy,Onshore wind energy,
Offshore wind energy,Renewable hydropower,Mixed Hydro Plants,Marine energy,Solid biofuels,
Renewable municipal waste,Liquid biofuels,Biogas,Geothermal energy,Total Non-Renewable,Pumped storage,
Coal and peat,Oil,Natural gas,Fossil fuels n.e.s.,Nuclear,Other non-renewable energy]

0510 Portugal restart on this country